// Archivo: MainViewModel.kt
import androidx.lifecycle.ViewModel
import com.example.madera.models.Saludo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MainViewModel : ViewModel() {
    // Estado que la Vista va a observar
    private val _texto = MutableStateFlow("¡Hola! Presiona el botón.")
    val texto: StateFlow<String> = _texto

    // Acción que ejecutará el botón
    fun cambiarMensaje() {
        val nuevoModelo = Saludo("¡Felicidades! Tu app MVVM funciona. 🎉")
        _texto.value = nuevoModelo.msj
    }
}
