package com.example.madera.models

data class Saludo (val msj: String){
}